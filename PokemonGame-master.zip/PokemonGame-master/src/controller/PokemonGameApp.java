package controller;

public class PokemonGameApp {
	public static void main(String[] args) {
		Controller c = new Controller();
		c.start();
	}
}
