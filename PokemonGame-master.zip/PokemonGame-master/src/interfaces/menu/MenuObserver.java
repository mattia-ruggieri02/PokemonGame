package interfaces.menu;

public interface MenuObserver {
	void initMenu();
	void leaderboardScreen();
	void teamScreen();
	void back();
	void profile();
}
