package interfaces.menu;

public interface GameTypeObserver {
	void initMenu();
	void singleBattle();
	void doubleBattle();
	void tripleBattle();
	void back();
}
