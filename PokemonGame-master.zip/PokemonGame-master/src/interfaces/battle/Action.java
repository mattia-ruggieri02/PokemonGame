package interfaces.battle;

import interfaces.Pokemon;

public interface Action {
	
	 Pokemon getAttacker();
	 int getId();
}
