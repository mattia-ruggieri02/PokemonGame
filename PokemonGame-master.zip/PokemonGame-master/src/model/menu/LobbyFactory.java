package model.menu;

import interfaces.menu.Lobby;

public interface LobbyFactory {
	Lobby createLobby();
}
