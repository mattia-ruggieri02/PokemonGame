package model;

public enum MoveType {
	FISICA,
	SPECIALE
}
