package model.battle;

public enum MoveTarget {
	SINGOLO,
	MULTIPLO
}
